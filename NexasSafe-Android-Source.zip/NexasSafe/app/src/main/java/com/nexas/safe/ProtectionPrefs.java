package com.nexas.safe;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.ComponentName;
import android.provider.Settings;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

final class ProtectionPrefs {
    static final String PREFS = "nexas_safe_v2";
    static final String KEY_FOCUS_UNTIL = "focus_until";
    static final String KEY_BLOCKED_PACKAGES = "blocked_packages";
    static final String KEY_KEYWORD_PROTECTION = "keyword_protection";
    static final String KEY_CUSTOM_KEYWORDS = "custom_keywords";
    static final String KEY_REMINDER_HOUR = "reminder_hour";
    static final String KEY_REMINDER_MINUTE = "reminder_minute";
    static final String KEY_REMINDER_MESSAGE = "reminder_message";
    static final String KEY_REMINDER_ENABLED = "reminder_enabled";
    static final String KEY_CURRENT_PACKAGE = "current_package";
    static final String KEY_LIVE_SCAN = "live_scan";
    static final String KEY_STRICT_MODE = "strict_mode";
    static final String KEY_BLOCK_SCREEN_TEXT = "block_screen_text";
    static final String KEY_BLOCK_SCREEN_IMAGE = "block_screen_image";
    static final String KEY_STREAK_COUNT = "streak_count";
    static final String KEY_BEST_STREAK = "best_streak";
    static final String KEY_FOCUS_POINTS = "focus_points";
    static final String KEY_LAST_COMPLETED_DAY = "last_completed_day";
    static final String KEY_LAST_COMPLETED_UNTIL = "last_completed_until";
    static final String KEY_FOCUS_DURATION = "focus_duration";
    static final String KEY_DAILY_INTENTION = "daily_intention";
    static final String KEY_DAILY_GOAL_MINUTES = "daily_goal_minutes";
    static final String KEY_FOCUS_DAY_KEY = "focus_day_key";
    static final String KEY_TODAY_FOCUS_MINUTES = "today_focus_minutes";

    private ProtectionPrefs() { }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean isFocusActive(Context context) {
        long until = prefs(context).getLong(KEY_FOCUS_UNTIL, 0L);
        if (until <= System.currentTimeMillis()) return false;
        return true;
    }

    static long focusUntil(Context context) {
        return prefs(context).getLong(KEY_FOCUS_UNTIL, 0L);
    }

    static boolean isStrictMode(Context context) {
        return prefs(context).getBoolean(KEY_STRICT_MODE, false);
    }

    static Set<String> blockedPackages(Context context) {
        String raw = prefs(context).getString(KEY_BLOCKED_PACKAGES, "");
        if (raw == null || raw.trim().isEmpty()) return Collections.emptySet();
        Set<String> result = new HashSet<>();
        for (String item : raw.split("[,\\n; ]+")) {
            String pkg = item.trim().toLowerCase(Locale.ROOT);
            if (pkg.matches("[a-z0-9_]+(\\.[a-z0-9_]+)+") && !pkg.equals(context.getPackageName())) result.add(pkg);
        }
        return result;
    }

    static void saveBlockedPackages(Context context, Set<String> packages) {
        StringBuilder builder = new StringBuilder();
        for (String pkg : packages) {
            if (pkg == null || pkg.equals(context.getPackageName())) continue;
            if (builder.length() > 0) builder.append(',');
            builder.append(pkg);
        }
        prefs(context).edit().putString(KEY_BLOCKED_PACKAGES, builder.toString()).apply();
    }


    static boolean isAccessibilityEnabled(Context context) {
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String target = new ComponentName(context, ProtectionAccessibilityService.class).flattenToString();
        for (String item : enabled.split(":")) if (target.equalsIgnoreCase(item)) return true;
        return false;
    }

    static String defaultKeywords() {
        return "porn, adult, xxx, hentai, erotic";
    }

    static boolean keywordProtectionEnabled(Context context) {
        return prefs(context).getBoolean(KEY_KEYWORD_PROTECTION, true);
    }

    static Set<String> keywords(Context context) {
        String raw = prefs(context).getString(KEY_CUSTOM_KEYWORDS, defaultKeywords());
        Set<String> result = new HashSet<>();
        if (raw == null) return result;
        for (String word : raw.toLowerCase(Locale.ROOT).split("[,\\n;]+")) {
            String value = word.trim();
            if (value.length() >= 3 && value.length() <= 40) result.add(value);
        }
        return result;
    }
}
