package com.nexas.safe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Explicit-consent, visible-notification live screen scan. Images stay in memory on this device. */
public class ScreenCaptureService extends Service {
    public static final String ACTION_STOP = "com.nexas.safe.STOP_SCREEN_SCAN";
    private static final int NOTIFICATION_ID = 5101;
    private static final String CHANNEL_ID = "nexas_live_scan";
    private static final long FRAME_INTERVAL_MS = 1100L;
    private static final long BLOCK_COOLDOWN_MS = 5000L;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread imageThread;
    private Handler imageHandler;
    private ExecutorService inferenceExecutor;
    private final AtomicBoolean inferenceBusy = new AtomicBoolean(false);
    private ImageSafetyClassifier classifier;
    private long lastInferenceAt;
    private long lastBlockAt;
    private volatile boolean stopping;
    private int width;
    private int height;
    private int densityDpi;

    @Override public void onCreate() {
        super.onCreate();
        imageThread = new HandlerThread("NexasScreenFrames");
        imageThread.start();
        imageHandler = new Handler(imageThread.getLooper());
        inferenceExecutor = Executors.newSingleThreadExecutor();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopCapture();
            return START_NOT_STICKY;
        }
        startAsForeground();
        if (projection != null) return START_NOT_STICKY;
        if (intent == null || !intent.hasExtra("resultCode") || !intent.hasExtra("projectionData") || !ModelManager.isReady(this)) {
            stopCapture();
            return START_NOT_STICKY;
        }
        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent resultData = intent.getParcelableExtra("projectionData");
        if (resultData == null) {
            stopCapture();
            return START_NOT_STICKY;
        }
        try {
            classifier = new ImageSafetyClassifier(ModelManager.modelFile(this));
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("Screen-capture permission was not granted");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopCapture(); }
            }, imageHandler);
            DisplayMetrics metrics = new DisplayMetrics();
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            wm.getDefaultDisplay().getRealMetrics(metrics);
            width = metrics.widthPixels;
            height = metrics.heightPixels;
            densityDpi = metrics.densityDpi;
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
            imageReader.setOnImageAvailableListener(reader -> inspectLatestFrame(reader), imageHandler);
            virtualDisplay = projection.createVirtualDisplay("Nexas Safe screen scan", width, height, densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, imageHandler);
            ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_LIVE_SCAN, true).apply();
            updateNotification("Live visual protection is active. Tap Stop to end this session.");
        } catch (Exception ex) {
            updateNotification("Screen scan could not start: " + ex.getMessage());
            stopCapture();
        }
        return START_NOT_STICKY;
    }

    private void inspectLatestFrame(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            long now = System.currentTimeMillis();
            if (now - lastInferenceAt < FRAME_INTERVAL_MS || !inferenceBusy.compareAndSet(false, true)) return;
            lastInferenceAt = now;
            Bitmap bitmap = imageToBitmap(image);
            if (bitmap == null) {
                inferenceBusy.set(false);
                return;
            }
            inferenceExecutor.execute(() -> {
                try {
                    String currentPackage = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_CURRENT_PACKAGE, "");
                    if (getPackageName().equals(currentPackage) || "com.android.systemui".equals(currentPackage)) return;
                    ImageSafetyClassifier.Result result = classifier.classify(bitmap);
                    if (result.flagged && System.currentTimeMillis() - lastBlockAt > BLOCK_COOLDOWN_MS) {
                        lastBlockAt = System.currentTimeMillis();
                        Intent blockSignal = new Intent(ProtectionAccessibilityService.ACTION_VISUAL_BLOCK);
                        blockSignal.setPackage(getPackageName());
                        sendBroadcast(blockSignal);
                        if (!ProtectionPrefs.isAccessibilityEnabled(this)) {
                            Intent block = new Intent(this, BlockActivity.class);
                            block.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            block.putExtra("reason", "image");
                            startActivity(block);
                        }
                    }
                } catch (Exception ignored) {
                    // Keep the screen monitor alive; the dashboard shows the service state.
                } finally {
                    if (!bitmap.isRecycled()) bitmap.recycle();
                    inferenceBusy.set(false);
                }
            });
        } catch (Exception ignored) {
            inferenceBusy.set(false);
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * width;
        Bitmap padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, width, height);
        padded.recycle();
        return cropped;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Live screen protection", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Visible status for the optional live screen analysis session");
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void startAsForeground() {
        Notification notification = buildNotification("Starting live visual protection…");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void updateNotification(String message) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(message));
    }

    private Notification buildNotification(String message) {
        Intent stop = new Intent(this, ScreenCaptureService.class).setAction(ACTION_STOP);
        android.app.PendingIntent stopPending = android.app.PendingIntent.getService(this, 5102, stop,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("Nexas Safe • Live scan")
                .setContentText(message)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Stop", stopPending)
                .build();
    }

    private synchronized void stopCapture() {
        if (stopping) return;
        stopping = true;
        ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_LIVE_SCAN, false).apply();
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) { }
        virtualDisplay = null;
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) { }
        imageReader = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { }
        projection = null;
        try { if (classifier != null) classifier.close(); } catch (Exception ignored) { }
        classifier = null;
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_LIVE_SCAN, false).apply();
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) { }
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) { }
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { }
        try { if (classifier != null) classifier.close(); } catch (Exception ignored) { }
        if (inferenceExecutor != null) inferenceExecutor.shutdownNow();
        if (imageThread != null) imageThread.quitSafely();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
