# Nexas Safe 3.3.1 — GitHub import

This archive is packaged with a top-level `NexasSafe/` folder and contains the corrected Java source plus a GitHub Actions workflow.

## Recommended new-repository setup

1. Create a GitHub repository named `nexas-safe-android` on the `main` branch.
2. Upload `NexasSafe-Android-Source.zip` to the repository root and commit it.
3. Create a new file with the exact path `.github/workflows/android.yml`.
4. Paste the contents of the separately supplied `android.yml` file and commit it.
5. Open **Actions** and run **Nexas Safe Android Build** if it did not start automatically.
6. When the run succeeds, download the `NexasSafe-debug-APK` artifact. Extract that artifact ZIP to obtain the APK.

The workflow file is supplied separately because GitHub does not activate a workflow buried inside an uploaded ZIP. The workflow can extract this archive and automatically locate `NexasSafe/gradlew`.

## Build configuration

- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (bootstrapped by the included `gradlew`)
- Android compile SDK: 35
- Workflow filename: `.github/workflows/android.yml`
- Workflow display name: `Nexas Safe Android Build`
- APK artifact: `NexasSafe-debug-APK`

## Validation note

The supplied previous GitHub Actions log showed one Java compiler error: `strokeColor` was an `int` but the code compared it to `null`. That error is fixed. This environment does not have an Android SDK installed, so the complete Android build must still be confirmed by GitHub Actions.
