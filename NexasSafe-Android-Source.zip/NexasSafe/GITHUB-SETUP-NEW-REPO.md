# Nexas Safe 3.3.1 — New GitHub Repository Setup

## Files
- Source archive: `NexasSafe-Android-Source.zip`
- Workflow file path in GitHub: `.github/workflows/android.yml`
- Workflow display name: `Nexas Safe Android Build`
- Expected APK artifact: `NexasSafe-debug-APK`

## Create the repository
1. In GitHub, create a new repository named `nexas-safe-android`.
2. Use the `main` branch. A public or private repository is fine.
3. Upload `NexasSafe-Android-Source.zip` to the repository root and commit it.
4. Create a new file with the exact path `.github/workflows/android.yml`.
5. Paste the contents of the separately supplied `android.yml` workflow file and commit it.
6. Open **Actions**. The workflow is named **Nexas Safe Android Build**. If it did not start automatically, choose it and tap **Run workflow**.
7. When the run is green, open it, scroll to **Artifacts**, and download `NexasSafe-debug-APK`. Extract the downloaded artifact ZIP to get `NexasSafe-debug.apk`.

The workflow supports either (a) the source ZIP uploaded to the repository root, or (b) the Android source tree extracted into the repository root. In ZIP mode, it automatically finds the nested `NexasSafe/gradlew` file.

## Build requirements
The project uses Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9, and Android SDK 35. The GitHub workflow installs the SDK packages and builds the debug APK.

## Important
A successful compile does not prove that all app behavior works correctly on every phone. Install and test the APK on your own device. Keep Android's standard recovery, permission-revocation, and uninstall controls available.
