# Nexas Safe Android 3.3.1 Creator Edition

A local-first Android focus and content-safety project. This is Android Studio source code, not a prebuilt APK.

## What's new in 2.1

- Premium dark visual system with deep navy surfaces, teal highlights, violet/amber accents, animated section entrances and button motion.
- Adaptive Android launcher icon and round icon resources.
- Focus Mode countdown continues when Nexas Safe is opened. Nexas Safe is explicitly excluded from the blocked-app list and ignored by its own Accessibility service.
- Strict Mode adds a 15-second pause before an early end, followed by a separate confirmation. The normal Android permission, Safe Mode, recovery and uninstall controls remain available; the app is not made undeletable.
- A redesigned block screen with a close control that opens the Nexas Safe dashboard without stopping the running timer.
- Editable block-screen reminder text and user-selected image.
- Focus streak, best-streak and point tracking. A completed timed session earns 25 points; the streak is updated once per calendar day.
- Two built-in focus activities: a guided breathing reset and a short pattern-memory game. Completing the memory game earns 5 points.
- Quick 25-minute sprint, custom duration, selected-app restrictions, keyword filtering and the existing optional on-device image/live scan flows.

The dashboard includes a 24-item feature overview. Some items describe shared capabilities rather than separate screens or independent modules.

## Build with GitHub Actions

1. Upload the contents of this `NexasSafe` folder to the repository root, preserving `.github/workflows/android.yml`.
2. Open the repository's **Actions** tab and run **Build Nexas Safe APK** (or push a code change to the configured branch).
3. Open the successful run and download the `NexasSafe-debug-APK` artifact. Extract the artifact ZIP to obtain the APK.

The workflow uses Java 17, Android SDK 35 and Gradle 8.9. The build downloads Android Gradle Plugin and TensorFlow Lite dependencies.

## First-run setup

1. Open Nexas Safe and install the optional on-device AI model if you intend to use image checks.
2. Enable Nexas Safe Protection in Android Accessibility settings only if you want text-based app filtering and app restrictions.
3. Choose the apps to block, set a duration, and start Focus Mode.
4. Use **Your Block Screen** to save a personal reminder and optionally select an image from the device.
5. Enable live screen analysis only after reading the Android screen-capture consent prompt. Android displays an ongoing notification during the capture session.

## Important limitations and safeguards

- The app does not prevent its own launch during Focus Mode. Opening Nexas Safe does not clear or pause the active timer.
- The close control on the block screen returns to Nexas Safe. It does not end Focus Mode.
- Strict Mode adds friction against impulsive early exits but deliberately does not disable Android's standard recovery, permission revocation or uninstall mechanisms.
- Android Accessibility can inspect only text exposed by another app. It cannot see every image, video frame, protected surface or canvas.
- The local visual classifier may miss content or flag harmless material. It is an imperfect additional filter, not a guarantee.
- Live visual scanning uses Android MediaProjection, requires explicit user approval and shows an ongoing notification. Some apps, DRM video and protected windows may not be capturable.
- App blocking depends on the user keeping Accessibility enabled and may vary by Android version and manufacturer.
- The streak reward is processed when Nexas Safe next resumes after a session reaches zero. If Android or the user clears the app's data, local streak information may be lost.

## Privacy

The app's text checks and image classifier run locally. Images selected for an AI test and live screen frames are processed on-device and are not uploaded by Nexas Safe. Accessibility reads exposed text only when the user enables the service.

## Project status

This is source code. It has not been compiled or device-tested in this environment because Android SDK and a local Gradle installation are unavailable here. Use the included GitHub Actions workflow to compile the APK, then test on the target phone. A successful build confirms compilation, not complete detection accuracy on every app or site.


## Version 3.0 Light Edition

This update introduces a light visual system, animated circular focus countdown, daily focus-minute goal, and a saved daily intention. Completed sessions update the current day's focus minutes and existing streak/points. The block screen uses the matching light palette. Strict Mode uses a 30-second early-end pause followed by confirmation; normal Android settings, recovery and uninstall controls remain available.

The countdown is stored as an absolute end timestamp so it remains accurate after app navigation or process restarts. The visual countdown uses vector drawing and scales to device density; it does not increase a device display's physical resolution.


## Version 3.1 — Visual Motion System

- Light palette refined with soft gradient accents, elevated cards, and clearer typographic hierarchy.
- A richer vector-drawn countdown dial with 60 minute marks, layered halo rings, a moving progress head, and 18 orbit particles. It scales with display density rather than relying on oversized bitmap art.
- All dashboard buttons use consistent ripple feedback, spring-like press/release motion, a subtle elevation response, and Android haptic feedback where the device permits it.
- Section headers receive their own animated glyph badges and pastel gradient treatments.
- Dashboard cards use staggered fade/slide/scale entrances; dialogs use shared fade/translate/scale transitions.
- The block screen now has matching motion, ripple feedback, and a softly pulsing shield mark.
- Fixed the Strict Mode early-exit copy to match its 30-second wait period.

### About “1000+ visuals”

The app uses a reusable, procedural visual system rather than embedding 1,000 large, repetitive image files. The countdown marks, particles, gradients, button ripples, interaction states, and motion timings are drawn or composed at runtime. This is lighter on storage and scales to different Android screen sizes. It does not claim 1,000 unique hand-authored illustrations.

## Build and verification

This ZIP contains Android Studio source code, not a prebuilt APK. The project was checked for ZIP integrity and XML well-formedness. An Android SDK/Gradle build and physical-device animation test were not available in this environment; use the GitHub Actions workflow to compile it and then test on the target phone.


## Version 3.2 — Completion Ring Countdown

- The focus countdown now uses a clockwise progress ring that starts empty and fills as focus time elapses.
- The remaining time stays readable in the centre of the ring.
- The moving progress marker follows the end of the completed arc.
- The centre label reads “TIME LEFT”; the lower label reports the percentage of the session completed.
- Android version metadata updated to 3.2.0.

The progress visual is drawn natively with Android Canvas, so it scales to the device display density and does not depend on a fixed-resolution 8K bitmap.


## Version 3.3 — Creator Profile Edition

- Added a dedicated About the Creator profile card near the top of the dashboard.
- Included the profile photo supplied by the app owner as a bundled local WebP resource (`drawable-nodpi/profile_shafi.webp`).
- Added an introduction, current ICS learning context, technology interests, projects/creative work, skills being developed, personal approach and future direction. These are framed as interests and work in progress rather than unsupported professional credentials.
- Added one-tap Instagram opening for `@shafi.viii_`, copy-handle action and Android share-sheet support.
- Kept the profile content local to the app; no profile upload or analytics endpoint was added.
- Updated Android `versionCode` to 7 and `versionName` to 3.3.0.

The creator photo is packaged in the APK as an app resource. Replace `app/src/main/res/drawable-nodpi/profile_shafi.webp` if the profile image needs to be updated later.


## Version 3.3.1 — Build correction and clean GitHub setup

- Fixed the Java compilation error in `MainActivity.gradient(...)`: `strokeColor` is a primitive `int`, so it is no longer compared with `null`; the gradient border is applied directly.
- Updated Android version metadata to `3.3.1` (`versionCode` 8).
- Updated the Gradle bootstrap download to retry transient network failures.
- Replaced the previous workflow with a workflow that supports either a ZIP uploaded at the repository root or an extracted source tree. It locates the Gradle project before building.
- Updated GitHub Actions to current major releases at the time this package was prepared.

The supplied GitHub Actions job log for the previous build showed one Java compiler error at `MainActivity.java:1413`: an `int` was compared with `null`. That specific error is fixed in this version. An Android SDK/Gradle build has not been executed inside this packaging environment, so the first run in the new repository remains the final compilation check.
